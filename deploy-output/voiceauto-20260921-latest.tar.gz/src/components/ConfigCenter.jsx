import React, { useEffect, useMemo, useState } from 'react';
import {
  CONFIG_SCHEMAS,
  CONFIG_TYPES,
  getOperationLogs,
  maskSensitiveValue,
  readConfig,
} from '../modules/config/secureConfigStore';
import { loadDatabaseConfig, saveDatabaseConfig } from '../modules/config/configApi';
import {
  buildDingTalkParameterRows,
  buildTapdParameterRows,
} from '../modules/config/parameterDisplay';
import { getLoginLogs, hasPermission, PERMISSIONS } from '../modules/config/authStore';
import {
  createUserAccount,
  deleteUserAccount,
  listUserAccounts,
  updateUserAccount,
} from '../modules/config/userApi';
import { refreshLangfuseEnvironments } from '../modules/langfuse/services/langfuseService';
import { useAuth } from './AuthGate';
import {
  getToolUsageRecords,
  filterToolUsageByUserName,
  formatToolUsageDuration,
  summarizeToolUsageByUser,
  TOOL_USAGE_UPDATED_EVENT,
} from '../utils/toolUsageStore';

const FIELD_LABELS = {
  configName: '配置名称',
  envKey: '环境 Key',
  label: '环境名称',
  proxyBase: '代理路径',
  baseUrl: 'Base URL',
  host: 'Host',
  publicKey: 'Public Key',
  secretKey: 'Secret Key',
  projectId: 'Project ID',
  workspaceId: 'Workspace ID',
  companyId: 'Company ID',
  tapdProjectId: 'TAPD Project ID',
  apiUser: 'API User',
  apiPassword: 'API Password',
  defaultTestPlanId: '默认测试计划 ID',
  timeout: '超时时间(ms)',
  webhook: 'Webhook',
  accessToken: 'Access Token',
  apiKey: 'API Key',
  apiKeyId: 'APP ID',
  apiKeySecret: 'Access Token',
  personalApiKeyId: 'APP ID',
  personalApiKeySecret: 'Access Token',
  personalSecretKey: 'Secret Key',
  personalResourceId: 'Resource ID',
  model: '模型',
  temperature: '温度',
  maxCompletionTokens: '最大输出 Tokens',
  codexBaseUrl: 'Base URL',
  codexApiKey: 'API Key',
  codexModel: '模型',
  codexMaxOutputTokens: '最大输出 Tokens',
  codexTimeout: '超时时间(ms)',
  secret: 'Secret',
  proxyPath: '代理路径',
  groupName: '群名称',
  provider: '服务厂商',
  url: '服务地址',
  appId: 'App ID',
  cluster: 'Cluster',
  defaultVoiceType: '默认音色',
  resourceId: 'Resource ID',
  uid: 'UID',
  type: '类型',
  port: '端口',
  databaseName: '数据库名',
  username: '账号',
  password: '密码',
  poolSize: '连接池',
  sslConfig: 'SSL 配置',
  backupStrategy: '备份策略',
  retentionDays: '保留周期(天)',
  serverName: '服务器名称',
  os: '操作系统',
  servicePort: '服务端口',
  deployPath: '部署路径',
  sshPort: 'SSH 端口',
  sshUser: 'SSH 账号',
  sshPassword: 'SSH 密码',
  sshPrivateKey: 'SSH 私钥',
  logPath: '日志路径',
  storagePath: '文件存储路径',
  adbPath: 'ADB 路径',
  adbDeviceId: 'ADB 设备',
  chromePath: 'Chrome 路径',
  startCommand: '启动命令',
  serviceStatus: '服务状态',
  enabled: '启用',
  debugDirectoryMapping: '目录调试',
};

const CONFIG_TABS = [
  CONFIG_TYPES.LANGFUSE,
  CONFIG_TYPES.TAPD,
  CONFIG_TYPES.DINGTALK,
  CONFIG_TYPES.DOUBAO_TTS,
  CONFIG_TYPES.MINIMAX,
];
const USER_MANAGEMENT_TAB = 'userManagement';
const USAGE_RECORDS_TAB = 'usageRecords';

const FIELD_ORDER = {
  [CONFIG_TYPES.LANGFUSE]: ['envKey', 'label', 'baseUrl', 'proxyBase', 'publicKey', 'secretKey', 'projectId', 'defaultTimeRange', 'maxLimit', 'timeout', 'enabled'],
  [CONFIG_TYPES.TAPD]: ['configName', 'baseUrl', 'workspaceId', 'companyId', 'tapdProjectId', 'apiUser', 'apiPassword', 'defaultTestPlanId', 'timeout', 'debugDirectoryMapping', 'enabled'],
  [CONFIG_TYPES.DINGTALK]: ['groupName', 'proxyPath', 'webhook', 'accessToken', 'secret', 'enabled'],
  [CONFIG_TYPES.DOUBAO_TTS]: ['activeAccount', 'apiKeyId', 'apiKeySecret', 'secretKey', 'resourceId', 'personalApiKeyId', 'personalApiKeySecret', 'personalSecretKey', 'personalResourceId'],
  [CONFIG_TYPES.MINIMAX]: ['activeProvider', 'configName', 'baseUrl', 'apiKey', 'model', 'temperature', 'maxCompletionTokens', 'timeout', 'codexBaseUrl', 'codexApiKey', 'codexModel', 'codexMaxOutputTokens', 'codexTimeout', 'enabled'],
  [CONFIG_TYPES.DATABASE]: ['type', 'host', 'port', 'databaseName', 'username', 'password', 'poolSize', 'sslConfig', 'backupStrategy', 'retentionDays', 'enabled'],
  [CONFIG_TYPES.SERVER]: ['serverName', 'host', 'os', 'servicePort', 'deployPath', 'sshPort', 'sshUser', 'sshPassword', 'sshPrivateKey', 'logPath', 'storagePath', 'adbPath', 'adbDeviceId', 'chromePath', 'startCommand', 'serviceStatus', 'enabled'],
};

const LARGE_MODEL_SECTIONS = [
  { provider: 'minimax', label: 'MiniMax', fields: ['configName', 'baseUrl', 'apiKey', 'model', 'temperature', 'maxCompletionTokens', 'timeout'] },
  { provider: 'codex', label: 'Codex', fields: ['codexBaseUrl', 'codexApiKey', 'codexModel', 'codexMaxOutputTokens', 'codexTimeout'] },
];

const DOUBAO_ACCOUNT_SECTIONS = [
  { account: 'personal', label: '个人账号', fields: ['personalApiKeyId', 'personalApiKeySecret', 'personalSecretKey', 'personalResourceId'] },
  { account: 'company', label: '公司账号', fields: ['apiKeyId', 'apiKeySecret', 'secretKey', 'resourceId'] },
];

function buildEditableFormFields(type, config) {
  const sensitive = new Set(CONFIG_SCHEMAS[type].sensitive);
  const editableFields = new Set(FIELD_ORDER[type] || Object.keys(config));
  return Object.entries(config).reduce((acc, [key, value]) => {
    if (!editableFields.has(key)) return acc;
    acc[key] = sensitive.has(key) ? maskSensitiveValue(value) : value;
    return acc;
  }, {});
}

function isUnchangedSensitiveDisplay(value, storedValue) {
  const displayValue = String(value ?? '').trim();
  const plainValue = String(storedValue ?? '').trim();
  if (!displayValue || !plainValue) return false;
  return displayValue === plainValue || displayValue === maskSensitiveValue(plainValue);
}

function buildConfigSubmitPayload(type, form, storedConfig) {
  const sensitive = new Set(CONFIG_SCHEMAS[type].sensitive);
  return Object.entries(form).reduce((payload, [field, value]) => {
    payload[field] = sensitive.has(field) && isUnchangedSensitiveDisplay(value, storedConfig[field])
      ? ''
      : value;
    return payload;
  }, {});
}

function ConfigSaveMessage({ type, message }) {
  if (!message) return null;
  const isSuccess = type === 'success';
  return (
    <div
      role="status"
      className={`rounded-lg border px-3 py-2 text-sm ${
        isSuccess
          ? 'border-emerald-700/70 bg-emerald-950/35 text-emerald-200'
          : 'border-red-800/70 bg-red-950/35 text-red-200'
      }`}
    >
      {message}
    </div>
  );
}

function ParameterLine({ label, value, onChange, disabled }) {
  return (
    <div className="grid grid-cols-[5.5rem_1fr] gap-3 text-sm md:text-base leading-7">
      <span className="text-gray-400 text-right">{label}：</span>
      <input
        value={value || ''}
        onChange={(event) => onChange?.(event.target.value)}
        disabled={disabled}
        className="w-full rounded-lg border border-gray-700 bg-gray-900 px-3 py-1.5 text-sm text-gray-100 outline-none focus:border-primary focus:ring-1 focus:ring-primary disabled:text-gray-500"
      />
    </div>
  );
}

function ParameterPreview({
  type,
  config,
  onDingTalkParameterChange,
  onTapdParameterChange,
  onLangfuseParameterChange,
  onLangfuseEnvironmentLabelChange,
  onLangfuseEnvironmentRemove,
  canManage,
}) {
  if (type === CONFIG_TYPES.TAPD) {
    const tapdFieldMap = {
      应用ID: 'apiUser',
      应用密钥: 'apiPassword',
      项目ID: 'workspaceId',
      公司ID: 'companyId',
    };
    return (
      <section className="rounded-lg border border-gray-700 bg-gray-950 px-5 py-4">
        <h4 className="text-base font-semibold text-white mb-4">TAPD参数：</h4>
        <div className="max-w-2xl space-y-2">
          {buildTapdParameterRows(config).map((row) => (
            <ParameterLine
              key={row.label}
              label={row.label}
              value={row.value}
              onChange={(value) => onTapdParameterChange?.(tapdFieldMap[row.label], value)}
              disabled={!canManage}
            />
          ))}
        </div>
      </section>
    );
  }

  if (type === CONFIG_TYPES.DINGTALK) {
    return (
      <section className="rounded-lg border border-gray-700 bg-gray-950 px-5 py-4">
        <h4 className="text-base font-semibold text-white mb-4">钉钉群消息参数：</h4>
        <div className="max-w-3xl space-y-3">
          {buildDingTalkParameterRows(config).map((row) => (
            <ParameterLine
              key={row.field}
              label={row.label}
              value={row.value}
              onChange={(value) => onDingTalkParameterChange?.(row.field, value)}
              disabled={!canManage}
            />
          ))}
        </div>
      </section>
    );
  }

  if (type === CONFIG_TYPES.LANGFUSE) {
    const environments = Array.isArray(config) ? config : [config];
    return (
      <section className="rounded-lg border border-gray-700 bg-gray-950 px-5 py-4">
        <h4 className="text-base font-semibold text-white mb-4">Langfuse参数：</h4>
        <p className="text-sm md:text-base text-gray-200 mb-4 pl-8">可自行在langfuse创建信息</p>
        <div className="space-y-6">
          {environments.map((environment, index) => (
            <div key={environment._uiId || `${environment.envKey || 'langfuse'}-${index}`} className="space-y-3 rounded-lg border border-gray-800 bg-gray-900/70 p-4">
              <div className="flex items-center justify-between gap-3">
                <input
                  value={environment.label || ''}
                  onChange={(event) => onLangfuseEnvironmentLabelChange?.(index, event.target.value)}
                  disabled={!canManage}
                  className="min-w-0 flex-1 rounded-lg border border-transparent bg-transparent px-2 py-1 text-sm md:text-base font-medium text-gray-100 outline-none focus:border-gray-600 focus:bg-gray-950 disabled:text-gray-500"
                />
                <button
                  type="button"
                  onClick={() => onLangfuseEnvironmentRemove?.(index)}
                  disabled={!canManage || environments.length <= 1}
                  className="rounded-lg border border-red-900/70 bg-red-950/40 px-3 py-1.5 text-xs text-red-200 hover:border-red-500 hover:text-red-100 disabled:border-gray-800 disabled:bg-gray-900 disabled:text-gray-600"
                >
                  删除环境
                </button>
              </div>
              <div className="max-w-3xl space-y-3">
                <ParameterLine
                  label="Secret Key"
                  value={environment.secretKey}
                  onChange={(value) => onLangfuseParameterChange?.(index, 'secretKey', value)}
                  disabled={!canManage}
                />
                <ParameterLine
                  label="Public Key"
                  value={environment.publicKey}
                  onChange={(value) => onLangfuseParameterChange?.(index, 'publicKey', value)}
                  disabled={!canManage}
                />
                <ParameterLine
                  label="Base URL"
                  value={environment.baseUrl}
                  onChange={(value) => onLangfuseParameterChange?.(index, 'baseUrl', value)}
                  disabled={!canManage}
                />
              </div>
            </div>
          ))}
        </div>
      </section>
    );
  }

  return null;
}

function emptyLangfuseEnvironment(index) {
  return {
    _uiId: `langfuse-env-${Date.now()}-${index}`,
    envKey: `ENV_${index + 1}`,
    label: `环境 ${index + 1}`,
    baseUrl: '',
    proxyBase: '',
    publicKey: '',
    secretKey: '',
    projectId: '',
    enabled: true,
  };
}

function buildLangfuseEditableForm(config) {
  const environments = config.environments?.length
    ? config.environments
    : [config];
  return {
    ...config,
    environments: environments.map((environment, index) => ({
      ...emptyLangfuseEnvironment(index),
      ...environment,
      _uiId: environment._uiId || `${environment.envKey || environment.label || 'langfuse-env'}-${index}`,
      publicKey: maskSensitiveValue(environment.publicKey),
      secretKey: maskSensitiveValue(environment.secretKey),
      projectId: maskSensitiveValue(environment.projectId),
    })),
  };
}

function buildLangfusePreviewEnvironments(storedConfig, form) {
  const storedEnvironments = storedConfig.environments?.length ? storedConfig.environments : [storedConfig];
  return (form.environments || []).map((environment, index) => {
    const stored = storedEnvironments.find((item) => item.envKey === environment.envKey) || storedEnvironments[index] || {};
    return {
      ...stored,
      ...environment,
      text: environment.parameterTextDraft,
    };
  });
}

function buildLangfuseSubmitPayload(form, storedConfig) {
  const storedEnvironments = storedConfig.environments?.length ? storedConfig.environments : [storedConfig];
  return {
    ...form,
    environments: (form.environments || []).map((environment, index) => {
      const stored = storedEnvironments.find((item) => item.envKey === environment.envKey)
        || storedEnvironments[index]
        || {};
      return {
        ...environment,
        publicKey: isUnchangedSensitiveDisplay(environment.publicKey, stored.publicKey) ? '' : environment.publicKey,
        secretKey: isUnchangedSensitiveDisplay(environment.secretKey, stored.secretKey) ? '' : environment.secretKey,
        projectId: isUnchangedSensitiveDisplay(environment.projectId, stored.projectId) ? '' : environment.projectId,
      };
    }),
  };
}

function LangfuseConfigForm({ onSaved, canManage }) {
  const [storedConfig, setStoredConfig] = useState(() => readConfig(CONFIG_TYPES.LANGFUSE));
  const [form, setForm] = useState(() => buildLangfuseEditableForm(storedConfig));
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');
  const [loading, setLoading] = useState(true);
  const previewEnvironments = buildLangfusePreviewEnvironments(storedConfig, form);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    loadDatabaseConfig(CONFIG_TYPES.LANGFUSE)
      .then((config) => {
        if (!mounted) return;
        setStoredConfig(config);
        setForm(buildLangfuseEditableForm(config));
      })
      .catch((error) => {
        if (mounted) {
          setMessageType('error');
          setMessage(error.message || '配置加载失败');
        }
      })
      .finally(() => {
        if (mounted) setLoading(false);
      });
    return () => {
      mounted = false;
    };
  }, []);

  const handleEnvironmentChange = (index, field, value) => {
    setForm((current) => ({
      ...current,
      environments: current.environments.map((environment, itemIndex) => (
        itemIndex === index ? { ...environment, [field]: value, parameterTextDraft: '' } : environment
      )),
    }));
  };

  const addEnvironment = () => {
    setForm((current) => ({
      ...current,
      environments: [
        ...current.environments,
        emptyLangfuseEnvironment(current.environments.length),
      ],
    }));
  };

  const removeEnvironment = (index) => {
    setForm((current) => ({
      ...current,
      environments: current.environments.length <= 1
        ? current.environments
        : current.environments.filter((_, itemIndex) => itemIndex !== index),
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!canManage) {
      setMessageType('error');
      setMessage('当前账号无配置修改权限');
      return;
    }
    setMessage('');
    setMessageType('');
    try {
      const saved = await saveDatabaseConfig(CONFIG_TYPES.LANGFUSE, buildLangfuseSubmitPayload(form, storedConfig));
      setStoredConfig(saved);
      setForm(buildLangfuseEditableForm(saved));
      refreshLangfuseEnvironments();
      setMessageType('success');
      setMessage('保存成功，配置已写入数据库');
      onSaved();
    } catch (error) {
      setMessageType('error');
      setMessage(error.message || '配置保存失败');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="rounded-lg border border-gray-700 bg-dark p-5 space-y-5">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h3 className="text-lg font-semibold text-white">Langfuse 配置</h3>
          <p className="text-xs text-gray-500 mt-1">版本 {storedConfig.version || 0}</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            className="px-3 py-2 rounded-lg border border-gray-700 bg-gray-900 hover:border-gray-500 disabled:text-gray-500 text-sm font-medium text-gray-200"
            type="button"
            onClick={addEnvironment}
            disabled={!canManage}
          >
            + 新增环境
          </button>
          <button
            className="px-4 py-2 rounded-lg bg-primary hover:bg-blue-500 disabled:bg-gray-700 disabled:text-gray-500 text-sm font-medium text-white"
            type="submit"
            disabled={!canManage}
          >
            保存配置
          </button>
        </div>
      </div>

      <ParameterPreview
        type={CONFIG_TYPES.LANGFUSE}
        config={previewEnvironments}
        onLangfuseParameterChange={handleEnvironmentChange}
        onLangfuseEnvironmentLabelChange={(index, value) => handleEnvironmentChange(index, 'label', value)}
        onLangfuseEnvironmentRemove={removeEnvironment}
        canManage={canManage}
      />

      {loading && <p className="text-sm text-gray-400">正在从数据库加载配置...</p>}
      <ConfigSaveMessage type={messageType} message={message} />
    </form>
  );
}

function ConfigForm({ type, onSaved, canManage }) {
  if (type === CONFIG_TYPES.LANGFUSE) {
    return <LangfuseConfigForm onSaved={onSaved} canManage={canManage} />;
  }

  const schema = CONFIG_SCHEMAS[type];
  const [storedConfig, setStoredConfig] = useState(() => readConfig(type));
  const [form, setForm] = useState(() => buildEditableFormFields(type, storedConfig));
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const sensitiveFields = new Set(schema.sensitive);
  const requiredFields = new Set(type === CONFIG_TYPES.MINIMAX && form.activeProvider === 'codex' ? ['codexApiKey']
    : type === CONFIG_TYPES.DOUBAO_TTS && form.activeAccount === 'personal' ? ['personalApiKeyId', 'personalApiKeySecret'] : schema.required);
  const previewConfig = {
    ...storedConfig,
    ...Object.fromEntries(Object.entries(form).filter(([field, value]) => !sensitiveFields.has(field) || String(value ?? '').trim())),
  };

  const handleChange = (field, value) => {
    setForm((current) => ({ ...current, [field]: value }));
  };

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    loadDatabaseConfig(type)
      .then((config) => {
        if (!mounted) return;
        setStoredConfig(config);
        setForm(buildEditableFormFields(type, config));
      })
      .catch((error) => {
        if (mounted) {
          setMessageType('error');
          setMessage(error.message || '配置加载失败');
        }
      })
      .finally(() => {
        if (mounted) setLoading(false);
      });
    return () => {
      mounted = false;
    };
  }, [type]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (loading || saving) return;
    if (!canManage) {
      setMessageType('error');
      setMessage('当前账号无配置修改权限');
      return;
    }
    setMessage('');
    setMessageType('');
    setSaving(true);
    try {
      const saved = await saveDatabaseConfig(type, buildConfigSubmitPayload(type, form, storedConfig));
      setStoredConfig(saved);
      setForm(buildEditableFormFields(type, saved));
      setMessageType('success');
      setMessage('保存成功，配置已写入数据库');
      onSaved();
    } catch (error) {
      setMessageType('error');
      setMessage(error.message || '配置保存失败');
    } finally {
      setSaving(false);
    }
  };

  const advancedFields = new Set(['timeout', 'temperature', 'maxCompletionTokens', 'debugDirectoryMapping']);
  const renderConfigField = (field) => {
          if (field === 'enabled' || field === 'debugDirectoryMapping') {
            return (
              <label key={field} className="flex items-center gap-3 rounded-lg border border-gray-700 bg-gray-900 px-3 py-3 text-sm text-gray-300">
                <input
                  type="checkbox"
                  className="accent-blue-500"
                  checked={Boolean(form[field])}
                onChange={(event) => handleChange(field, event.target.checked)}
                  disabled={!canManage}
                />
                <span>{FIELD_LABELS[field] || field}</span>
              </label>
            );
          }

          return (
            <label key={field} className="space-y-1.5">
              <span className="text-xs text-gray-400">
                {FIELD_LABELS[field] || field}
                {requiredFields.has(field) && <span className="text-red-300 ml-1">*</span>}
                {sensitiveFields.has(field) && <span className="text-yellow-300 ml-1">敏感</span>}
              </span>
              <input
                value={form[field] ?? ''}
                type="text"
                onChange={(event) => handleChange(field, event.target.value)}
                disabled={!canManage}
                placeholder={sensitiveFields.has(field) && readConfig(type).hasSecrets ? '输入新值后保存' : ''}
                className="w-full px-3 py-2 bg-gray-900 border border-gray-700 rounded-lg text-sm text-white placeholder-gray-600 focus:border-primary focus:ring-1 focus:ring-primary"
              />
            </label>
          );

  };

  return (
    <form onSubmit={handleSubmit} className="rounded-lg border border-gray-700 bg-dark p-5 space-y-5">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h3 className="text-lg font-semibold text-white">{schema.label}</h3>
          <p className="text-xs text-gray-500 mt-1">版本 {readConfig(type).version || 0}</p>
        </div>
        <button
          className="px-4 py-2 rounded-lg bg-primary hover:bg-blue-500 disabled:bg-gray-700 disabled:text-gray-500 text-sm font-medium text-white"
          type="submit"
          disabled={!canManage || loading || saving}
        >
          保存配置
        </button>
      </div>

      <ParameterPreview
        type={type}
        config={previewConfig}
        onDingTalkParameterChange={handleChange}
        onTapdParameterChange={handleChange}
        canManage={canManage}
      />

      {loading && <p className="text-sm text-gray-400">正在从数据库加载配置...</p>}
      {type === CONFIG_TYPES.MINIMAX && (
        <fieldset disabled={!canManage || loading || saving} className="space-y-4">
          <legend className="text-sm text-gray-300 mb-3">选择当前使用的模型（保存后生效）</legend>
          {renderConfigField('enabled')}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            {LARGE_MODEL_SECTIONS.map((section) => (
              <section key={section.provider} className={`rounded-lg border p-4 space-y-4 ${form.activeProvider === section.provider ? 'border-primary bg-blue-950/15' : 'border-gray-700'}`}>
                <label className="flex items-center gap-3 text-white font-medium cursor-pointer">
                  <input type="radio" name="large-model-provider" value={section.provider}
                    checked={form.activeProvider === section.provider}
                    onChange={() => handleChange('activeProvider', section.provider)}
                    className="accent-blue-500" />
                  {section.label}
                </label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {section.fields.map(renderConfigField)}
                </div>
              </section>
            ))}
          </div>
          <p className="text-xs text-gray-400">两套参数独立保留，评测仅调用所选模型。Codex 使用 OpenAI API Key。</p>
        </fieldset>
      )}
      {type === CONFIG_TYPES.DOUBAO_TTS && (
        <fieldset disabled={!canManage || loading || saving} className="space-y-4">
          <legend className="mb-3 text-sm text-gray-300">选择生成音频使用的账号（保存后生效）</legend>
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            {DOUBAO_ACCOUNT_SECTIONS.map(section => (
              <section key={section.account} className={`rounded-lg border p-4 space-y-4 ${form.activeAccount === section.account ? 'border-primary bg-blue-950/15' : 'border-gray-700'}`}>
                <label className="flex items-center gap-3 text-white font-medium cursor-pointer">
                  <input type="radio" name="doubao-account" value={section.account}
                    checked={form.activeAccount === section.account}
                    onChange={() => handleChange('activeAccount', section.account)} className="accent-blue-500" />
                  {section.label}
                </label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">{section.fields.map(renderConfigField)}</div>
              </section>
            ))}
          </div>
          <p className="text-xs text-gray-400">两套账号参数独立保存，测试音频和唤醒音频使用当前选中的账号。</p>
        </fieldset>
      )}
      {![CONFIG_TYPES.TAPD, CONFIG_TYPES.DINGTALK, CONFIG_TYPES.MINIMAX, CONFIG_TYPES.DOUBAO_TTS].includes(type) && (
      <>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {(FIELD_ORDER[type] || []).filter(field => !advancedFields.has(field)).map(renderConfigField)}
        </div>
        {(FIELD_ORDER[type] || []).some(field => advancedFields.has(field)) && (
          <details className="rounded-lg border border-gray-700 p-3">
            <summary className="cursor-pointer text-sm text-gray-400">高级设置</summary>
            <div className="mt-3 grid grid-cols-1 gap-4 md:grid-cols-2">
              {(FIELD_ORDER[type] || []).filter(field => advancedFields.has(field)).map(renderConfigField)}
            </div>
          </details>
        )}
      </>
      )}

      <ConfigSaveMessage type={messageType} message={message} />
    </form>
  );
}

function OperationLogPanel({ refreshKey }) {
  const logs = useMemo(() => getOperationLogs().slice().reverse(), [refreshKey]);
  const loginLogs = useMemo(() => getLoginLogs().slice().reverse(), [refreshKey]);
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <div className="rounded-lg border border-gray-700 bg-dark p-5">
        <h3 className="text-sm font-semibold text-gray-200 mb-3">配置变更记录</h3>
        <div className="max-h-56 overflow-y-auto space-y-2">
          {logs.length === 0 && <p className="text-xs text-gray-500">暂无记录</p>}
          {logs.map((log) => (
            <div key={log.id} className="flex items-center justify-between gap-3 rounded-lg bg-gray-900 px-3 py-2 text-xs">
              <span className="text-gray-300">{log.summary}</span>
              <span className="text-gray-500">{new Date(log.createdAt).toLocaleString('zh-CN', { hour12: false })}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="rounded-lg border border-gray-700 bg-dark p-5">
        <h3 className="text-sm font-semibold text-gray-200 mb-3">登录记录</h3>
        <div className="max-h-56 overflow-y-auto space-y-2">
          {loginLogs.length === 0 && <p className="text-xs text-gray-500">暂无记录</p>}
          {loginLogs.map((log) => (
            <div key={log.id} className="flex items-center justify-between gap-3 rounded-lg bg-gray-900 px-3 py-2 text-xs">
              <span className={log.loginResult === '成功' ? 'text-emerald-300' : 'text-red-300'}>
                {log.loginAccount} · {log.loginResult}
              </span>
              <span className="text-gray-500">{new Date(log.loginTime).toLocaleString('zh-CN', { hour12: false })}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ToolUsagePanel({ refreshKey }) {
  const [userNameQuery, setUserNameQuery] = useState('');
  const records = useMemo(() => getToolUsageRecords(), [refreshKey]);
  const filteredRecords = useMemo(() => filterToolUsageByUserName(records, userNameQuery), [records, userNameQuery]);
  const summaryRows = useMemo(() => summarizeToolUsageByUser(filteredRecords), [filteredRecords]);
  const recentRecords = filteredRecords.slice(0, 12);
  const totalDuration = summaryRows.reduce((total, row) => total + row.totalDurationMs, 0);

  return (
    <section className="rounded-lg border border-gray-700 bg-dark p-5 space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h3 className="text-sm font-semibold text-gray-200">测试信息统计</h3>
          <p className="text-xs text-gray-500 mt-1">记录每次测试的开始测试、结束测试、测试时长和测试人</p>
        </div>
        <span className="text-xs text-gray-400" role="status">共 {filteredRecords.length} 次测试记录 · 累计使用时长：{formatToolUsageDuration(totalDuration)}</span>
      </div>

      <div className="flex items-end gap-3 flex-wrap">
        <label className="space-y-1.5 flex-1 min-w-0 max-w-sm">
          <span className="text-xs text-gray-300">用户名称</span>
          <input type="search" value={userNameQuery}
            onChange={(event) => setUserNameQuery(event.target.value)}
            placeholder="输入用户名称查询时长，支持模糊匹配"
            className="w-full px-3 py-2 bg-gray-900 border border-gray-700 rounded-lg text-sm text-white placeholder-gray-500 focus:border-primary focus:ring-1 focus:ring-primary" />
        </label>
        <button type="button" onClick={() => setUserNameQuery('')} disabled={!userNameQuery}
          className="px-3 py-2 rounded-lg border border-gray-700 text-sm text-gray-300 hover:border-gray-500 disabled:opacity-50">清空</button>
      </div>

      {summaryRows.length === 0 ? (
        <p className="text-xs text-gray-500">{userNameQuery.trim() ? '未找到匹配用户的使用记录' : '暂无工具使用记录'}</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-[760px] w-full text-xs">
            <thead className="bg-gray-950/70 text-gray-400">
              <tr>
                <th className="px-3 py-2 text-left font-medium">用户</th>
                <th className="px-3 py-2 text-left font-medium">登录账号</th>
                <th className="px-3 py-2 text-right font-medium">测试次数</th>
                <th className="px-3 py-2 text-right font-medium">累计使用时长</th>
                <th className="px-3 py-2 text-left font-medium">最近开始时间</th>
                <th className="px-3 py-2 text-left font-medium">最近结束时间</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {summaryRows.map((item) => (
                <tr key={item.loginAccount} className="hover:bg-gray-900/60">
                  <td className="px-3 py-2 text-gray-200">{item.userName}</td>
                  <td className="px-3 py-2 text-gray-300">{item.loginAccount}</td>
                  <td className="px-3 py-2 text-right text-gray-300">{item.runCount}</td>
                  <td className="px-3 py-2 text-right text-emerald-300 font-semibold">{item.totalDurationText}</td>
                  <td className="px-3 py-2 text-gray-400">{item.lastStartTimeText}</td>
                  <td className="px-3 py-2 text-gray-400">{item.lastEndTimeText}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {recentRecords.length > 0 && (
        <div className="border-t border-gray-800 pt-4">
          <h4 className="text-xs font-semibold text-gray-300 mb-2">测试明细（最近 {recentRecords.length} 条）</h4>
          <div className="overflow-x-auto">
            <table className="min-w-[760px] w-full text-xs">
              <thead className="bg-gray-950/70 text-gray-400">
                <tr>
                  <th className="px-3 py-2 text-left font-medium">测试人</th>
                  <th className="px-3 py-2 text-left font-medium">测试项目</th>
                  <th className="px-3 py-2 text-left font-medium">登录账号</th>
                  <th className="px-3 py-2 text-left font-medium">开始测试</th>
                  <th className="px-3 py-2 text-left font-medium">结束测试</th>
                  <th className="px-3 py-2 text-right font-medium">测试时长</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800">
                {recentRecords.map((record) => (
                  <tr key={record.id} className="hover:bg-gray-900/60">
                    <td className="px-3 py-2 text-gray-200">{record.userName}</td>
                    <td className="px-3 py-2 text-gray-300">{record.testProject || '未记录'}</td>
                    <td className="px-3 py-2 text-gray-300">{record.loginAccount}</td>
                    <td className="px-3 py-2 text-gray-400">{record.startTimeText}</td>
                    <td className="px-3 py-2 text-gray-400">{record.endTimeText}</td>
                    <td className="px-3 py-2 text-right text-emerald-300 font-semibold">{record.durationText}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </section>
  );
}

function UserManagementPanel({ canManageUsers }) {
  const [users, setUsers] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({
    username: '',
    loginAccount: '',
    password: '',
    role: 'test_lead',
    status: 'enabled',
  });
  const [form, setForm] = useState({
    username: '',
    loginAccount: '',
    password: '',
    role: 'test_lead',
    status: 'enabled',
  });
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleChange = (field, value) => {
    setForm((current) => ({ ...current, [field]: value }));
  };

  const handleEditChange = (field, value) => {
    setEditForm((current) => ({ ...current, [field]: value }));
  };

  const startEdit = (user) => {
    setEditingId(user.id);
    setEditForm({
      username: user.username || '',
      loginAccount: user.loginAccount || '',
      password: '',
      role: user.role || 'test_lead',
      status: user.status || 'enabled',
    });
    setMessage('');
    setMessageType('');
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditForm({
      username: '',
      loginAccount: '',
      password: '',
      role: 'test_lead',
      status: 'enabled',
    });
  };

  const loadUsers = async () => {
    if (!canManageUsers) return;
    setLoadingUsers(true);
    const result = await listUserAccounts();
    setLoadingUsers(false);
    if (!result.success) {
      setMessageType('error');
      setMessage(result.message || '账号列表加载失败');
      return;
    }
    setUsers(result.users);
  };

  useEffect(() => {
    loadUsers();
  }, [canManageUsers]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!canManageUsers) {
      setMessageType('error');
      setMessage('当前账号无新增账号权限');
      return;
    }
    setSaving(true);
    setMessage('');
    setMessageType('');
    const result = await createUserAccount(form);
    setSaving(false);
    if (!result.success) {
      setMessageType('error');
      setMessage(result.message || '新增账号失败');
      return;
    }
    setMessageType('success');
    setMessage(`账号 ${result.user.loginAccount} 已创建`);
    setUsers((current) => [result.user, ...current.filter((user) => user.loginAccount !== result.user.loginAccount)]);
    setForm({
      username: '',
      loginAccount: '',
      password: '',
      role: 'test_lead',
      status: 'enabled',
    });
    await loadUsers();
  };

  const handleSaveEdit = async (userId) => {
    if (!canManageUsers) {
      setMessageType('error');
      setMessage('当前账号无账号管理权限');
      return;
    }
    setSaving(true);
    setMessage('');
    setMessageType('');
    const result = await updateUserAccount(userId, editForm);
    setSaving(false);
    if (!result.success) {
      setMessageType('error');
      setMessage(result.message || '修改账号失败');
      return;
    }
    setUsers((current) => current.map((user) => (
      String(user.id) === String(userId) ? result.user : user
    )));
    cancelEdit();
    setMessageType('success');
    setMessage(`账号 ${result.user.loginAccount} 已更新`);
    await loadUsers();
  };

  const handleToggleStatus = async (user) => {
    const nextStatus = user.status === 'enabled' ? 'disabled' : 'enabled';
    const result = await updateUserAccount(user.id, {
      username: user.username,
      loginAccount: user.loginAccount,
      role: user.role,
      status: nextStatus,
      password: '',
    });
    if (!result.success) {
      setMessageType('error');
      setMessage(result.message || '账号状态修改失败');
      return;
    }
    setUsers((current) => current.map((item) => (
      String(item.id) === String(user.id) ? result.user : item
    )));
    setMessageType('success');
    setMessage(`账号 ${result.user.loginAccount} 已${nextStatus === 'enabled' ? '启用' : '禁用'}`);
    await loadUsers();
  };

  const handleDelete = async (user) => {
    if (!window.confirm(`确认删除账号 ${user.loginAccount} 吗？`)) return;
    const result = await deleteUserAccount(user.id);
    if (!result.success) {
      setMessageType('error');
      setMessage(result.message || '删除账号失败');
      return;
    }
    setUsers((current) => current.filter((item) => String(item.id) !== String(user.id)));
    if (String(editingId) === String(user.id)) cancelEdit();
    setMessageType('success');
    setMessage(`账号 ${user.loginAccount} 已删除`);
    await loadUsers();
  };

  return (
    <section className="rounded-lg border border-gray-700 bg-dark p-5 space-y-5">
      <form onSubmit={handleSubmit} className="space-y-5">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h3 className="text-lg font-semibold text-white">账号管理</h3>
          <p className="text-xs text-gray-500 mt-1">新增账号后可直接使用后端登录接口登录</p>
        </div>
        <button
          className="px-4 py-2 rounded-lg bg-primary hover:bg-blue-500 disabled:bg-gray-700 disabled:text-gray-500 text-sm font-medium text-white"
          type="submit"
          disabled={!canManageUsers || saving}
        >
          {saving ? '保存中...' : '新增账号'}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <label className="space-y-1.5">
          <span className="text-xs text-gray-400">用户名</span>
          <input
            value={form.username}
            onChange={(event) => handleChange('username', event.target.value)}
            disabled={!canManageUsers || saving}
            className="w-full px-3 py-2 bg-gray-900 border border-gray-700 rounded-lg text-sm text-white focus:border-primary focus:ring-1 focus:ring-primary"
          />
        </label>
        <label className="space-y-1.5">
          <span className="text-xs text-gray-400">登录账号</span>
          <input
            value={form.loginAccount}
            onChange={(event) => handleChange('loginAccount', event.target.value)}
            disabled={!canManageUsers || saving}
            className="w-full px-3 py-2 bg-gray-900 border border-gray-700 rounded-lg text-sm text-white focus:border-primary focus:ring-1 focus:ring-primary"
          />
        </label>
        <label className="space-y-1.5">
          <span className="text-xs text-gray-400">初始密码</span>
          <input
            value={form.password}
            type="password"
            onChange={(event) => handleChange('password', event.target.value)}
            disabled={!canManageUsers || saving}
            className="w-full px-3 py-2 bg-gray-900 border border-gray-700 rounded-lg text-sm text-white focus:border-primary focus:ring-1 focus:ring-primary"
          />
        </label>
        <label className="space-y-1.5">
          <span className="text-xs text-gray-400">角色</span>
          <select
            value={form.role}
            onChange={(event) => handleChange('role', event.target.value)}
            disabled={!canManageUsers || saving}
            className="w-full px-3 py-2 bg-gray-900 border border-gray-700 rounded-lg text-sm text-white focus:border-primary focus:ring-1 focus:ring-primary"
          >
            <option value="test_lead">测试负责人</option>
            <option value="admin">管理员</option>
          </select>
        </label>
      </div>

      {message && (
        <p className={`text-sm ${messageType === 'success' ? 'text-emerald-300' : 'text-red-300'}`}>
          {message}
        </p>
      )}
      </form>

      <div className="border-t border-gray-800 pt-5">
        <div className="flex items-center justify-between gap-3 mb-3">
          <h4 className="text-sm font-semibold text-gray-200">已创建账号</h4>
          <button
            type="button"
            onClick={loadUsers}
            disabled={!canManageUsers || loadingUsers}
            className="rounded-lg border border-gray-700 bg-gray-900 px-3 py-1.5 text-xs text-gray-200 hover:border-gray-500 disabled:text-gray-500"
          >
            {loadingUsers ? '刷新中...' : '刷新'}
          </button>
        </div>
        {!canManageUsers && <p className="text-xs text-gray-500">当前账号无账号管理权限</p>}
        {canManageUsers && users.length === 0 && !loadingUsers && (
          <p className="text-xs text-gray-500">暂无账号</p>
        )}
        {users.length > 0 && (
          <div className="overflow-x-auto">
            <table className="min-w-[960px] w-full text-xs">
              <thead className="bg-gray-950/70 text-gray-400">
                <tr>
                  <th className="px-3 py-2 text-left font-medium">用户名</th>
                  <th className="px-3 py-2 text-left font-medium">登录账号</th>
                  <th className="px-3 py-2 text-left font-medium">新密码</th>
                  <th className="px-3 py-2 text-left font-medium">角色</th>
                  <th className="px-3 py-2 text-left font-medium">状态</th>
                  <th className="px-3 py-2 text-left font-medium">最后登录</th>
                  <th className="px-3 py-2 text-right font-medium">操作</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800">
                {users.map((user) => {
                  const isEditing = String(editingId) === String(user.id);
                  return (
                    <tr key={user.id || user.loginAccount} className="hover:bg-gray-900/60">
                      <td className="px-3 py-2 text-gray-200">
                        {isEditing ? (
                          <input
                            value={editForm.username}
                            onChange={(event) => handleEditChange('username', event.target.value)}
                            className="w-32 rounded border border-gray-700 bg-gray-950 px-2 py-1 text-gray-100"
                          />
                        ) : (user.username || '-')}
                      </td>
                      <td className="px-3 py-2 text-gray-300">
                        {isEditing ? (
                          <input
                            value={editForm.loginAccount}
                            onChange={(event) => handleEditChange('loginAccount', event.target.value)}
                            className="w-36 rounded border border-gray-700 bg-gray-950 px-2 py-1 text-gray-100"
                          />
                        ) : user.loginAccount}
                      </td>
                      <td className="px-3 py-2 text-gray-400">
                        {isEditing ? (
                          <input
                            value={editForm.password}
                            type="password"
                            placeholder="留空不修改"
                            onChange={(event) => handleEditChange('password', event.target.value)}
                            className="w-32 rounded border border-gray-700 bg-gray-950 px-2 py-1 text-gray-100 placeholder-gray-600"
                          />
                        ) : '-'}
                      </td>
                      <td className="px-3 py-2 text-gray-400">
                        {isEditing ? (
                          <select
                            value={editForm.role}
                            onChange={(event) => handleEditChange('role', event.target.value)}
                            className="w-28 rounded border border-gray-700 bg-gray-950 px-2 py-1 text-gray-100"
                          >
                            <option value="test_lead">测试负责人</option>
                            <option value="admin">管理员</option>
                          </select>
                        ) : (user.role === 'admin' ? '管理员' : '测试负责人')}
                      </td>
                      <td className={user.status === 'enabled' ? 'px-3 py-2 text-emerald-300' : 'px-3 py-2 text-red-300'}>
                        {isEditing ? (
                          <select
                            value={editForm.status}
                            onChange={(event) => handleEditChange('status', event.target.value)}
                            className="w-20 rounded border border-gray-700 bg-gray-950 px-2 py-1 text-gray-100"
                          >
                            <option value="enabled">启用</option>
                            <option value="disabled">禁用</option>
                          </select>
                        ) : (user.status === 'enabled' ? '启用' : '禁用')}
                      </td>
                      <td className="px-3 py-2 text-gray-500">
                        {user.lastLoginTime ? new Date(user.lastLoginTime).toLocaleString('zh-CN', { hour12: false }) : '-'}
                      </td>
                      <td className="px-3 py-2">
                        <div className="flex justify-end gap-2">
                          {isEditing ? (
                            <>
                              <button
                                type="button"
                                onClick={() => handleSaveEdit(user.id)}
                                disabled={saving}
                                className="rounded border border-emerald-700 bg-emerald-950/40 px-2 py-1 text-emerald-200 hover:border-emerald-500 disabled:text-gray-500"
                              >
                                保存
                              </button>
                              <button
                                type="button"
                                onClick={cancelEdit}
                                disabled={saving}
                                className="rounded border border-gray-700 bg-gray-900 px-2 py-1 text-gray-300 hover:border-gray-500"
                              >
                                取消
                              </button>
                            </>
                          ) : (
                            <>
                              <button
                                type="button"
                                onClick={() => startEdit(user)}
                                className="rounded border border-gray-700 bg-gray-900 px-2 py-1 text-gray-200 hover:border-gray-500"
                              >
                                修改
                              </button>
                              <button
                                type="button"
                                onClick={() => handleToggleStatus(user)}
                                className="rounded border border-amber-800 bg-amber-950/30 px-2 py-1 text-amber-200 hover:border-amber-500"
                              >
                                {user.status === 'enabled' ? '禁用' : '启用'}
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDelete(user)}
                                className="rounded border border-red-900 bg-red-950/40 px-2 py-1 text-red-200 hover:border-red-500"
                              >
                                删除
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </section>
  );
}

export default function ConfigCenter() {
  const auth = useAuth();
  const [activeType, setActiveType] = useState(CONFIG_TYPES.LANGFUSE);
  const [refreshKey, setRefreshKey] = useState(0);
  const refresh = () => setRefreshKey((value) => value + 1);
  const isAdminUser = auth?.currentUser?.role === 'admin';
  const canManage = isAdminUser;
  const canManageUsers = isAdminUser;

  useEffect(() => {
    const onToolUsageUpdated = () => refresh();
    window.addEventListener(TOOL_USAGE_UPDATED_EVENT, onToolUsageUpdated);
    return () => window.removeEventListener(TOOL_USAGE_UPDATED_EVENT, onToolUsageUpdated);
  }, []);

  useEffect(() => {
    const onOpenConfigType = (event) => {
      const requestedType = event?.detail?.type;
      if (CONFIG_TABS.includes(requestedType)) setActiveType(requestedType);
    };
    window.addEventListener('voiceauto:open-config-type', onOpenConfigType);
    return () => window.removeEventListener('voiceauto:open-config-type', onOpenConfigType);
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h2 className="text-xl font-semibold text-white">配置中心</h2>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {CONFIG_TABS.map((type) => (
          <button
            key={type}
            onClick={() => setActiveType(type)}
            className={`px-3 py-2 rounded-lg border text-sm transition-colors ${
              activeType === type
                ? 'bg-primary border-primary text-white'
                : 'bg-dark border-gray-700 text-gray-300 hover:border-gray-500'
            }`}
          >
            {CONFIG_SCHEMAS[type].label}
          </button>
        ))}
        <button
          onClick={() => setActiveType(USER_MANAGEMENT_TAB)}
          className={`px-3 py-2 rounded-lg border text-sm transition-colors ${
            activeType === USER_MANAGEMENT_TAB
              ? 'bg-primary border-primary text-white'
              : 'bg-dark border-gray-700 text-gray-300 hover:border-gray-500'
          }`}
        >
          账号管理
        </button>
        <button
          onClick={() => setActiveType(USAGE_RECORDS_TAB)}
          className={`px-3 py-2 rounded-lg border text-sm transition-colors ${
            activeType === USAGE_RECORDS_TAB
              ? 'bg-primary border-primary text-white'
              : 'bg-dark border-gray-700 text-gray-300 hover:border-gray-500'
          }`}
        >
          使用统计与操作记录
        </button>
      </div>

      {activeType === USER_MANAGEMENT_TAB ? (
        <UserManagementPanel canManageUsers={canManageUsers} />
      ) : activeType === USAGE_RECORDS_TAB ? (
        <div className="space-y-4">
          <ToolUsagePanel refreshKey={refreshKey} />
          <OperationLogPanel refreshKey={refreshKey} />
        </div>
      ) : (
        <ConfigForm key={activeType} type={activeType} onSaved={refresh} canManage={canManage} />
      )}
    </div>
  );
}
