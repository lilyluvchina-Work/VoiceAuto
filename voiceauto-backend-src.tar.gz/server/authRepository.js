import { createHash, randomBytes } from 'node:crypto';

export const ROLE_PERMISSIONS = {
  admin: [
    'user_manage',
    'config_view',
    'config_manage',
    'config_test',
    'test_execute',
    'report_generate',
    'report_view',
    'operation_log_view',
  ],
  test_lead: [
    'config_view',
    'test_execute',
    'report_generate',
    'report_view',
  ],
};

function hashPassword(password, salt, algorithm) {
  if (algorithm !== 'sha256_salt_v1') {
    return '';
  }
  return createHash('sha256').update(`${salt}${password}`).digest('hex');
}

function createPasswordRecord(password) {
  const salt = randomBytes(16).toString('hex');
  return {
    salt,
    hash: hashPassword(password, salt, 'sha256_salt_v1'),
    algorithm: 'sha256_salt_v1',
  };
}

function toPublicUser(row) {
  if (!row) return null;
  const role = row.role || 'test_lead';
  return {
    id: row.id,
    username: row.username,
    loginAccount: row.login_account,
    role,
    status: row.status,
    lastLoginTime: row.last_login_time,
    permissions: ROLE_PERMISSIONS[role] || [],
  };
}

export async function authenticateUser(pool, loginAccount, password, metadata = {}) {
  const account = String(loginAccount ?? '').trim();
  const passwordText = String(password ?? '');
  if (!account || !passwordText) {
    return { success: false, status: 400, message: '请填写账号和密码' };
  }

  const result = await pool.query(
    `SELECT id, username, login_account, password_hash, password_salt, password_algorithm,
            role, status, last_login_time, created_at, updated_at
       FROM user_account
      WHERE login_account = $1
      LIMIT 1`,
    [account]
  );
  const row = result.rows[0];

  let message = '';
  let userId = null;
  if (!row) {
    message = '账号不存在';
  } else if (row.status !== 'enabled') {
    message = '账号已禁用';
    userId = row.id;
  } else if (hashPassword(passwordText, row.password_salt, row.password_algorithm) !== row.password_hash) {
    message = '密码错误';
    userId = row.id;
  }

  if (message) {
    await writeLoginLog(pool, {
      userId,
      loginAccount: account,
      loginIp: metadata.ipAddress || '',
      loginResult: '失败',
      failReason: message,
    });
    return { success: false, status: message === '账号不存在' ? 404 : 401, message };
  }

  await pool.query(
    'UPDATE user_account SET last_login_time = NOW(), updated_at = NOW() WHERE id = $1',
    [row.id]
  ).catch(() => {});
  await writeLoginLog(pool, {
    userId: row.id,
    loginAccount: account,
    loginIp: metadata.ipAddress || '',
    loginResult: '成功',
    failReason: '',
  });

  return { success: true, user: toPublicUser(row) };
}

export async function findUserById(pool, userId) {
  const result = await pool.query(
    `SELECT id, username, login_account, role, status, last_login_time, created_at, updated_at
       FROM user_account
      WHERE id = $1
      LIMIT 1`,
    [userId]
  );
  return toPublicUser(result.rows[0]);
}

export async function createUserAccount(pool, input) {
  const username = String(input.username ?? '').trim();
  const loginAccount = String(input.loginAccount ?? '').trim();
  const password = String(input.password ?? '');
  const role = String(input.role || 'test_lead').trim();
  const status = String(input.status || 'enabled').trim();

  if (!username || !loginAccount || !password) {
    return { success: false, status: 400, message: '请填写用户名、登录账号和密码' };
  }
  if (!ROLE_PERMISSIONS[role]) {
    return { success: false, status: 400, message: '角色不存在' };
  }
  if (!['enabled', 'disabled'].includes(status)) {
    return { success: false, status: 400, message: '账号状态不合法' };
  }

  const passwordRecord = createPasswordRecord(password);
  try {
    const result = await pool.query(
      `INSERT INTO user_account (
         username, login_account, password_hash, password_salt, password_algorithm,
         role, status, created_at, updated_at
       )
       VALUES ($1, $2, $3, $4, $5, $6, $7, NOW(), NOW())
       RETURNING id, username, login_account, role, status, last_login_time, created_at, updated_at`,
      [username, loginAccount, passwordRecord.hash, passwordRecord.salt, passwordRecord.algorithm, role, status]
    );
    return { success: true, user: toPublicUser(result.rows[0]) };
  } catch (error) {
    if (error?.code === '23505') {
      return { success: false, status: 409, message: '登录账号已存在' };
    }
    throw error;
  }
}

export function createSession(sessionStore, user) {
  const sessionId = randomBytes(32).toString('hex');
  sessionStore.set(sessionId, {
    userId: user.id,
    createdAt: Date.now(),
  });
  return sessionId;
}

async function writeLoginLog(pool, log) {
  await pool.query(
    `INSERT INTO user_login_log (user_id, login_account, login_ip, login_result, fail_reason)
     VALUES ($1, $2, $3, $4, $5)`,
    [log.userId, log.loginAccount, log.loginIp, log.loginResult, log.failReason]
  ).catch(() => {});
}
