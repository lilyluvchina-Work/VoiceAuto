import { createReadStream, existsSync, statSync } from 'node:fs';
import { extname, join, normalize, resolve } from 'node:path';
import {
  authenticateUser,
  createUserAccount,
  createSession,
  findUserById,
} from './authRepository.js';
import {
  listAppConfigs,
  readAppConfig,
  saveAppConfig,
} from './configRepository.js';

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.ico': 'image/x-icon',
};

function sendJson(res, status, body, headers = {}) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(payload),
    ...headers,
  });
  res.end(payload);
}

async function readJson(req) {
  const chunks = [];
  for await (const chunk of req) {
    chunks.push(chunk);
  }
  const text = Buffer.concat(chunks).toString('utf8').trim();
  if (!text) return {};
  return JSON.parse(text);
}

function parseCookies(header = '') {
  return String(header)
    .split(';')
    .map((part) => part.trim())
    .filter(Boolean)
    .reduce((acc, part) => {
      const index = part.indexOf('=');
      if (index === -1) return acc;
      acc[decodeURIComponent(part.slice(0, index))] = decodeURIComponent(part.slice(index + 1));
      return acc;
    }, {});
}

function getClientIp(req) {
  return String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
}

async function resolveSessionUser(req, pool, sessionStore) {
  const sessionId = parseCookies(req.headers.cookie).voiceauto_session;
  if (!sessionId) return null;
  const session = sessionStore.get(sessionId);
  if (!session) return null;
  return findUserById(pool, session.userId);
}

function hasPermission(user, permission) {
  return Boolean(user?.permissions?.includes(permission));
}

function routeStatic(req, res, staticDir) {
  if (!staticDir) {
    sendJson(res, 404, { success: false, message: 'Not found' });
    return;
  }

  const requestPath = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
  const safePath = normalize(requestPath).replace(/^(\.\.[/\\])+/, '');
  let filePath = resolve(staticDir, safePath === '/' ? 'index.html' : safePath.slice(1));
  const root = resolve(staticDir);
  if (!filePath.startsWith(root)) {
    sendJson(res, 403, { success: false, message: 'Forbidden' });
    return;
  }
  if (!existsSync(filePath) || statSync(filePath).isDirectory()) {
    filePath = join(root, 'index.html');
  }
  if (!existsSync(filePath)) {
    sendJson(res, 404, { success: false, message: 'Not found' });
    return;
  }

  res.writeHead(200, {
    'Content-Type': MIME_TYPES[extname(filePath)] || 'application/octet-stream',
  });
  createReadStream(filePath).pipe(res);
}

export function createApp(options) {
  const pool = options.pool;
  const sessionStore = options.sessionStore || new Map();
  const staticDir = options.staticDir || join(process.cwd(), 'dist');

  return async function app(req, res) {
    const url = new URL(req.url, 'http://localhost');
    try {
      if (req.method === 'POST' && url.pathname === '/api/auth/login') {
        const body = await readJson(req);
        const result = await authenticateUser(pool, body.loginAccount ?? body.username, body.password, {
          ipAddress: getClientIp(req),
        });
        if (!result.success) {
          sendJson(res, result.status || 401, result);
          return;
        }
        const sessionId = createSession(sessionStore, result.user);
        sendJson(res, 200, result, {
          'Set-Cookie': `voiceauto_session=${encodeURIComponent(sessionId)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=28800`,
        });
        return;
      }

      if (req.method === 'GET' && url.pathname === '/api/auth/profile') {
        const user = await resolveSessionUser(req, pool, sessionStore);
        if (!user) {
          sendJson(res, 401, { success: false, message: '未登录' });
          return;
        }
        sendJson(res, 200, { success: true, user });
        return;
      }

      if (req.method === 'POST' && url.pathname === '/api/auth/logout') {
        const sessionId = parseCookies(req.headers.cookie).voiceauto_session;
        if (sessionId) sessionStore.delete(sessionId);
        sendJson(res, 200, { success: true }, {
          'Set-Cookie': 'voiceauto_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0',
        });
        return;
      }

      if (req.method === 'POST' && url.pathname === '/api/users') {
        const currentUser = await resolveSessionUser(req, pool, sessionStore);
        if (!currentUser) {
          sendJson(res, 401, { success: false, message: '未登录' });
          return;
        }
        if (!hasPermission(currentUser, 'user_manage')) {
          sendJson(res, 403, { success: false, message: '无账号管理权限' });
          return;
        }

        const body = await readJson(req);
        const result = await createUserAccount(pool, body);
        sendJson(res, result.success ? 201 : (result.status || 400), result);
        return;
      }

      if (req.method === 'GET' && url.pathname === '/api/configs') {
        const currentUser = await resolveSessionUser(req, pool, sessionStore);
        if (!currentUser) {
          sendJson(res, 401, { success: false, message: '未登录' });
          return;
        }
        if (!hasPermission(currentUser, 'config_view')) {
          sendJson(res, 403, { success: false, message: '无配置查看权限' });
          return;
        }
        const configs = await listAppConfigs(pool);
        sendJson(res, 200, { success: true, configs });
        return;
      }

      const configMatch = url.pathname.match(/^\/api\/configs\/([^/]+)$/);
      if (configMatch && req.method === 'GET') {
        const currentUser = await resolveSessionUser(req, pool, sessionStore);
        if (!currentUser) {
          sendJson(res, 401, { success: false, message: '未登录' });
          return;
        }
        if (!hasPermission(currentUser, 'config_view')) {
          sendJson(res, 403, { success: false, message: '无配置查看权限' });
          return;
        }
        const configType = decodeURIComponent(configMatch[1]);
        const config = await readAppConfig(pool, configType);
        sendJson(res, 200, {
          success: true,
          config: config ? { ...config, ...config.payload } : { type: configType, configured: false },
        });
        return;
      }

      if (configMatch && req.method === 'PUT') {
        const currentUser = await resolveSessionUser(req, pool, sessionStore);
        if (!currentUser) {
          sendJson(res, 401, { success: false, message: '未登录' });
          return;
        }
        if (!hasPermission(currentUser, 'config_manage')) {
          sendJson(res, 403, { success: false, message: '无配置修改权限' });
          return;
        }
        const body = await readJson(req);
        const configType = decodeURIComponent(configMatch[1]);
        const saved = await saveAppConfig(pool, configType, body.config || {}, currentUser.loginAccount);
        sendJson(res, 200, { success: true, config: { ...saved, ...saved.payload } });
        return;
      }

      if (url.pathname.startsWith('/api/')) {
        sendJson(res, 404, { success: false, message: '接口不存在' });
        return;
      }

      if (req.method === 'GET' || req.method === 'HEAD') {
        routeStatic(req, res, staticDir);
        return;
      }

      sendJson(res, 405, { success: false, message: 'Method not allowed' });
    } catch (error) {
      sendJson(res, 500, { success: false, message: error?.message || '服务异常' });
    }
  };
}
