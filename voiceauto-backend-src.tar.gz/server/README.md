# VoiceAuto Backend

The backend is a small Node HTTP service that serves the built frontend from `dist/` and exposes authentication APIs under `/api/auth/*`.

## Required Environment

```bash
DATABASE_URL=postgresql://postgres@127.0.0.1:5432/voiceauto
PORT=3000
DB_POOL_SIZE=10
```

For local Vite development, run the backend on `3002` so Vite can keep `3000`:

```bash
PORT=3002 DATABASE_URL=postgresql://voiceauto_app:<password>@10.10.64.202:5432/voiceauto npm start
```

Vite proxies `/api/*` to `http://127.0.0.1:3002`.

For Docker on the same host as PostgreSQL, use:

```bash
DATABASE_URL=postgresql://postgres@host.docker.internal:5432/voiceauto
```

The existing `user_account` table must contain:

- `login_account`
- `password_hash`
- `password_salt`
- `password_algorithm = sha256_salt_v1`
- `role`
- `status`

## APIs

- `POST /api/auth/login`
- `GET /api/auth/profile`
- `POST /api/auth/logout`

Successful login sets an HttpOnly `voiceauto_session` cookie.
