import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react';

const API_PROXY_TARGET = process.env.VITE_API_PROXY_TARGET
  || process.env.API_PROXY_TARGET
  || 'http://10.10.64.202:8890';

// Langfuse 各环境目标地址（与后端约定保持一致）
const LANGFUSE_HOSTS = {
  uat:  'https://monitor-live-test-cedar.sdmc.tv',
  'uat-local': 'https://monitor-live-test-cedar.sdmc.tv',
  test: 'https://monitor-live-test-cedar.sdmc.tv',
  'test-local': 'https://monitor-live-test-cedar.sdmc.tv',
  prod: 'https://monitor-live-test-cedar.sdmc.tv',
  'prod-local': 'https://monitor-live-test-cedar.sdmc.tv',
};

function langfuseProxy(envSuffix) {
  return {
    target: LANGFUSE_HOSTS[envSuffix],
    changeOrigin: true,
    rewrite: (path) => path.replace(new RegExp(`^/langfuse-api-${envSuffix}`), ''),
    secure: false,
    timeout: 60000,
    proxyTimeout: 60000,
  };
}

export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 3000,
    strictPort: true,
    open: true,
    proxy: {
      '/api': {
        target: API_PROXY_TARGET,
        changeOrigin: true,
      },
      '/langfuse-api-uat-local': langfuseProxy('uat-local'),
      '/langfuse-api-uat':  langfuseProxy('uat'),
      '/langfuse-api-test-local': langfuseProxy('test-local'),
      '/langfuse-api-test': langfuseProxy('test'),
      '/langfuse-api-prod-local': langfuseProxy('prod-local'),
      '/langfuse-api-prod': langfuseProxy('prod'),
      // TAPD API 代理（避免跨域限制）
      '/tapd-api': {
        target: 'https://api.tapd.cn',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/tapd-api/, ''),
        secure: false,
      },
      '/dingtalk-robot': {
        target: 'https://oapi.dingtalk.com',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/dingtalk-robot/, '/robot/send'),
        secure: false,
      },
    }
  }
})
